﻿using System;
using System.Web;
using System.Web.UI;
using System.Collections.Generic;
using System.Data;

namespace DoorWeb
{

    public partial class judge : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SaveJudge();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        private void SaveJudge()
        {
            string applySeq = common.GetQueryString("seq");
            string judge = common.GetQueryString("judge");
            string applyStatus = judge.Equals("Y") ? applyStatus = "ASB" : applyStatus = "ASC";
            string returnCode = string.Empty;
            string error = string.Empty;
            string cmdText
                = "UPDATE db_doormanage.tbl_enter_apply "
                + "SET enter_apply_status = @enter_apply_status "
                + "WHERE "
                + "seq = @seq";

            Dictionary<string, object> cmdParam = new Dictionary<string, object>();
            cmdParam.Add("@seq", applySeq);
            cmdParam.Add("@enter_apply_status", applyStatus);
            dbcon.ExecuteNonQuery(cmdText, cmdParam, out returnCode, out error);

            cmdText
                = "SELECT T1.OUTER_EMAIL, T2.DETAIL_NAME " 
                + "FROM DB_DOORMANAGE.TBL_ENTER_APPLY T1 " 
                + "JOIN DB_DOORMANAGE.TBL_CODE T2 ON T1.ENTER_APPLY_STATUS = T2.DETAIL AND T2.GROUP = 'AS' "
                + "WHERE  SEQ = @SEQ";
            cmdParam.Clear();
            cmdParam.Add("@SEQ", applySeq);
            DataTable dataTable = dbcon.GetDataTable(cmdText, cmdParam, out returnCode, out error);
            if(returnCode == "0000" && dataTable.Rows.Count == 1)
            {
                string mail_to = common.GetStrVal(dataTable.Rows[0]["OUTER_EMAIL"]);
                string subject = "출입신청 결과를 알려드립니다.";
                string context = "출입신청이 " +  common.GetStrVal(dataTable.Rows[0]["DETAIL_NAME"]) + "되었습니다.";
                smtp.EmailSend(mail_to, subject, context,out error,out returnCode);
            }

            string message = "저장되었습니다";
            if (returnCode != "0000") message = error;
            Response.Write("<script type='text/javascript'>alert('" + message + "'); window.close();</script>");

        }
    }
}
