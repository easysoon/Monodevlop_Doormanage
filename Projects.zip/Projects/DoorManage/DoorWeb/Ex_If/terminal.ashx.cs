﻿using System;
using System.Web;
using System.Web.SessionState;
using System.Collections.Generic;
using System.Data;
using Newtonsoft.Json.Linq;
namespace DoorWeb.Ex_If
{

    public class terminal : System.Web.IHttpHandler
    {
        public bool IsReusable { get { return false; } }

        public void ProcessRequest(HttpContext context)
        {
            string result = string.Empty;
            result = MainFunction();
            context.Response.ContentType = "text/plain";
            context.Response.Write(result);

            GC.Collect();
            GC.WaitForPendingFinalizers();
            Console.WriteLine(DateTime.Now.ToLongTimeString() + " - " + result);
        }

        private string MainFunction()
        {
            string type = common.GetForm("type");
            string data = common.GetForm("DATA");

            JObject jObject = JObject.Parse(data);

            switch (type)
            {
                case "LOGIN":
                    LoginProcess(jObject);
                    break;
                case "CHECK":
                    CheckOuter(jObject);
                    break;
            }
            return jObject["RETURNDATA"].ToString();
        }

        private void CheckOuter(JObject jObject)
        {
            string error = string.Empty;
            string returnCode = "0000";
            JArray jArray = new JArray();
            string cmdText
                = "SELECT " 
            	+ "ENTER_APPLY_STATUS, T2.OUTER_NAME, DATEDIFF(CURDATE(), T1.VALID_BEGIN) CAL1, DATEDIFF(T1.VALID_END, CURDATE()) CAL2 "
                + "FROM TBL_ENTER_APPLY T1 " 
                + "JOIN TBL_OUTER T2 ON T1.OUTER_EMAIL = T2.OUTER_EMAIL " 
                + "WHERE T1.SEQ = @SEQ ";
            Dictionary<string, object> cmdParam = new Dictionary<string, object>();
            cmdParam.Add("@SEQ", int.Parse(jObject["SEQ"].ToString()));
            DataTable dataTable = dbcon.GetDataTable(cmdText, cmdParam, out returnCode, out error);

            if (returnCode != "0000")
            {
                returnCode = "FAIL";
            }
            else if (dataTable.Rows.Count != 1)
            {//0=미가입. 1초과=해킹.
                error = "Invalid Card No.";
                returnCode = "FAIL";
            }
            else
            {
                DataRow datarow = dataTable.Rows[0];
                string valid = string.Empty;
                
                 DefineValid(datarow, jObject, ref valid, ref returnCode);

                JObject jobTmp = new JObject
                         (
                         new JProperty("VALID", valid),
                         new JProperty("SEQ", jObject["SEQ"].ToString()),
                         new JProperty("TIME", DateTime.Now.ToString("HH:mm:ss") ),
                         new JProperty("OUTER_NAME", common.GetStrVal(datarow["OUTER_NAME"]))
                         );
                jArray.Add(jobTmp);
            }

            jObject.Add(new JProperty("RETURNDATA", new JObject(
                new JProperty("DATA",
                    new JObject(
                        new JProperty("ERROR", error),
                        new JProperty("CODE", returnCode),
                        new JProperty("PERSONINFO", jArray))))));

            SaveEnterLog(jObject);
        }

        private void DefineValid(DataRow dataRow, JObject jObject, ref string valid, ref string returnCode)
        {
            string requestIO = jObject["IO"].ToString();
            string gateID = jObject["GI"].ToString();
            valid = "VRA";

            try
            {
                int cal1 = int.Parse(common.GetStrVal(dataRow["CAL1"]));
                int cal2 = int.Parse(common.GetStrVal(dataRow["CAL2"]));
                string enterApplyStatus = common.GetStrVal(dataRow["ENTER_APPLY_STATUS"]);
                if(enterApplyStatus != "ASB") { valid = "VRB"; }
                else if (cal1 < 0) { valid = "VRB"; }
                else if (cal2 < 0) { valid = "VRB"; }
            }
            catch(Exception ex)
            {
                common.Writelog("Line 114 : " + ex.Message);
                valid = "VRB";
            }

            if (valid.Equals("VRB")) returnCode = "FAIL";

        }

        private void SaveEnterLog(JObject jObject)
        {
            string valid = "VRB";

            if (common.GetStrVal(jObject["RETURNDATA"]["CODE"]) == "0000")
                valid = common.GetStrVal(jObject["RETURNDATA"]["PERSONINFO"]["VALID"]);

            string cmdText = "INSERT INTO TBL_ENTER_HISTORY "
            + "( VALID, REQUEST_IO,  APPLY_SEQ, GATE_ID) "
            + "VALUES (@VALID, @REQUEST_IO, @APPLY_SEQ, @GATE_ID);";
            string returnCode, error;
            Dictionary<string, object> cmdParam = new Dictionary<string, object>();
            cmdParam.Add("@VALID", valid);
            cmdParam.Add("@REQUEST_IO", common.GetStrVal(jObject["IO"]));
            cmdParam.Add("@APPLY_SEQ", int.Parse(common.GetStrVal(jObject["SEQ"])));
            cmdParam.Add("@GATE_ID", common.GetStrVal(jObject["RETURNDATA"]["GI"]));
            dbcon.ExecuteNonQuery(cmdText, cmdParam, out returnCode, out error);

            if (returnCode != "0000")
            {
                common.Writelog("Line 141 - " + jObject.ToString());
            }
        }

        private void LoginProcess(JObject jObject)
        {
            string error = string.Empty;
            string returnCode = "0000";
            JArray jArray = new JArray();
            string cmdText
                = "SELECT EMP_ID, EMP_PASSWORD, EMP_NAME "
                + "FROM TBL_EMPLOYEE " 
                + "WHERE EMP_ID = @EMP_ID ";
            Dictionary<string, object> cmdParam = new Dictionary<string, object>();
            cmdParam.Add("@EMP_ID", common.GetStrVal(jObject["LOGINID"]));
            DataTable dataTable = dbcon.GetDataTable(cmdText, cmdParam, out returnCode, out error);

            if (returnCode != "0000") returnCode = "FAIL";
            else if (dataTable.Rows.Count != 1)
            {//0=미가입. 1초과=해킹.
                error = "Wrong ID";
                returnCode = "FAIL";
            }
            else if (common.GetStrVal(dataTable.Rows[0]["EMP_PASSWORD"]) != common.GetStrVal(jObject["LOGINPW"])) 
            {
                error = "Wrong Password.";
                returnCode = "FAIL";
            }
            else
            {
                foreach (DataRow datarow in dataTable.Rows)
                {
                    JObject jobTmp = new JObject
                             (
                             new JProperty("GI", common.GetStrVal(datarow["EMP_ID"])),
                             new JProperty("NAME", common.GetStrVal(datarow["EMP_NAME"]))
                             );
                    jArray.Add(jobTmp);
                }
            }
            jObject.Add(new JProperty("RETURNDATA", new JObject(
                new JProperty("DATA",
                    new JObject(
                        new JProperty("ERROR", error),
                        new JProperty("CODE", returnCode),
                        new JProperty("GATEINFO", jArray))))));
        }
    }
}