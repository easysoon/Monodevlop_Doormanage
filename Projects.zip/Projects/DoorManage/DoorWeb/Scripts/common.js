﻿/* Ajax Process
Session, Loading Image
*/
function get_ajax(url, param, trg_obj, options) {

    var defaults = {
        type: 'post',
        async: true,
        dataType: 'text',
        callback: '',
        check_session: true
    }

    var extend_options = $.extend(defaults, options);
    
    /* session pass : ajax process  */
    $.ajax({
        url: url,
        data: param,
        type: extend_options.type,
        async: extend_options.async,
        dataType: extend_options.dataType,
        success: function (data) {
            extend_options.callback(data);
        },
        error: function (data) {
            alert(data.responseText);
        }
    });
}

function get_ajax_form(url, param, trg_obj, options) {
    // param : only json type {"name":"value", "name1":"value2"}
    // trg_obj : only form

    var defaults = {
        type: 'post',
        async: true,
        prog_mode: '',
        callback: '',
        check_session: true
    }

    var extend_options = $.extend(defaults, options);

    if (extend_options.prog_mode == 'blind') {
        create_blindloading();
    }

    /* session pass : ajax process  */
    trg_obj.ajaxForm({
        url: url,
        data: param,
        async: extend_options.async,
        success: function (data) {

            if (extend_options.callback === '') {
                trg_obj.html(data);
            }
            else {
                if (data == '<PRE></PRE>') {// ie8 bug
                    data = '';
                }
                extend_options.callback(data);
            }

            if (extend_options.prog_mode == 'blind') {
                $('#container_loading').remove();
            }
        },
        error: function (data) {
            alert(data.responseText);

            if (extend_options.prog_mode == 'blind') {
                $('#container_loading').remove();
            }
        }
    }).submit();
}

// firefox add event listener
function do_ff_eventadd() {
    if (navigator.userAgent.indexOf('Firefox') >= 0) {
        var eventNames = ["mousedown", "mouseover", "mouseout",
	                            "mousemove", "mousedrag", "click", "dblclick",
	                            "keydown", "keypress", "keyup"];

        for (var i = 0; i < eventNames.length; i++) {
            window.addEventListener(eventNames[i], function (e) {
                window.event = e;
            }, true);
        }
    }
}


/* email validation */
function check_emailvalidation(str) {

    if (str.length == 0) return false;
    if (str.length > 50) return false;

    var regExp = /^[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*@([0-9a-zA-Z_-]+)(\.[0-9a-zA-Z_-]+){1,2}$/;
    if (!regExp.test(str)) 
    {
        return false;
    }
    else
        return true;


}

/* number validation */
function check_numbervalidation(str) {

    // value check
    if (str.length > 0) {
        var regExp = /^[0-9]*$/;
        if (!regExp.test(str)) {
            return false;
        }
        else
            return true;
    }
    else
        return false;
}
