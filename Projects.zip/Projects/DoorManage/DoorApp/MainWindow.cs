﻿using System;
using Gtk;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;

public partial class MainWindow : Gtk.Window
{
    public MainWindow() : base(Gtk.WindowType.Toplevel)
    {
        Build();
    }

    protected void OnDeleteEvent(object sender, DeleteEventArgs a)
    {
        Application.Quit();
        a.RetVal = true;
    }

    protected void OnMapEvent(object o, MapEventArgs args)
    {
        JObject config = common.ReadConfig();
        if (config.Count == 0) return;
        ent_login_id.Text = common.GetStrVal(config.Property("LOGINID").Value);
        ent_login_pw.Text = common.GetStrVal(config.Property("LOGINPW").Value);
        btn_login.Click();
    }

    protected void OnBtnLoginClicked(object sender, EventArgs e)
    {
        string loginId = ent_login_id.Text;
        string loginPw = ent_login_pw.Text;
        string error = string.Empty;
        string result = string.Empty;
        Dictionary<string, string> httpParams = new Dictionary<string, string>();
        lbl_login_error.Text = "";

        if (string.IsNullOrWhiteSpace(loginId) || loginId.Length > 20  )
        {
            lbl_login_error.Text = "아이디를 올바르게 입력해주세요.";
            return;
        }
        else if (string.IsNullOrWhiteSpace(loginPw) || loginPw.Length > 20)
        {
            lbl_login_error.Text = "비밀번호를 올바르게 입력해주세요.";
            return;
        }

        try
        {
            JObject jObject = new JObject(
                        new JProperty("LOGINID", loginId),
                        new JProperty("LOGINPW", loginPw)
                        );
            httpParams.Add("DATA", jObject.ToString());
            httpParams.Add("type", "LOGIN");

            string tmpReturn = common.GetHttpResponse(httpParams, out error);
            if (!string.IsNullOrEmpty(error)) throw new Exception(error);

            JObject jObjectReturn = JObject.Parse(tmpReturn);
            if (common.GetStrVal(jObjectReturn["DATA"]["CODE"]) != "0000") 
                throw new Exception(common.GetStrVal(jObjectReturn["DATA"]["ERROR"]));

            jObject.Add("GI", jObjectReturn["DATA"]["GATEINFO"][0]["GI"]);
            jObject.Add("NAME", jObjectReturn["DATA"]["GATEINFO"][0]["NAME"]);

            common.WriteConfig(jObject);

            DoorApp.CheckWindow checkWindow = new DoorApp.CheckWindow();
            checkWindow.SetPosition(WindowPosition.CenterAlways);
            this.Hide();

        }
        catch (Exception ex)
        {
            lbl_login_error.Text = ex.Message;
        }

    }


    #region Useless Events Test

    protected void OnExposeEvent(object o, ExposeEventArgs args)
    {
    }

    protected void OnDefaultActivated(object sender, EventArgs e)
    {
    }

    protected void OnEntBarcodeChanged(object sender, EventArgs e)
    {
        //common.Writelog("OnEntBarcodeChanged");

    }

    protected void OnFixWaitKeyPressEvent(object o, KeyPressEventArgs args)
    {
        //common.Writelog("OnFixWaitKeyPressEvent");
    }

    protected void OnFixWaitAdded(object o, AddedArgs args)
    {
        //common.Writelog("OnFixWaitAdded");
    }

    protected void OnFixWaitKeyReleaseEvent(object o, KeyReleaseEventArgs args)
    {
        //common.Writelog("OnFixWaitKeyReleaseEvent");
    }

    protected void OnFixWaitShown(object sender, EventArgs e)
    {
        //common.Writelog("OnFixWaitShown");
    }

    protected void OnAdded(object o, AddedArgs args)
    {
        //common.Writelog("OnAdded");
    }

    protected void OnSetFocus(object o, SetFocusArgs args)
    {
        //common.Writelog("OnSetFocus");
    }

    protected void OnFocusActivated(object sender, EventArgs e)
    {
        //common.Writelog("OnFocusActivated");
    }

    protected void OnFrameEvent(object o, FrameEventArgs args)
    {
        //common.Writelog("OnFocusActivated");
    }

    protected void OnKeysChanged(object sender, EventArgs e)
    {
        //common.Writelog("OnKeysChanged");
    }
    /*
    protected void OnMoveFocus(object o, MoveFocusArgs args)
    {
        //common.Writelog("OnMoveFocus");
    }*/

    protected void OnResizeChecked(object sender, EventArgs e)
    {
        //common.Writelog("OnResizeChecked");
    }

    protected void OnRemoved(object o, RemovedArgs args)
    {
        //common.Writelog("OnRemoved");
    }

    protected void OnFocusChildSet(object o, FocusChildSetArgs args)
    {
        //common.Writelog("OnFocusChildSet");
    }

    protected void OnAccelCanActivate(object o, AccelCanActivateArgs args)
    {
        //common.Writelog("OnAccelCanActivate");
    }

    protected void OnAccelClosuresChanged(object sender, EventArgs e)
    {
        //common.Writelog("OnAccelClosuresChanged");
    }

    protected void OnButtonPressEvent(object o, ButtonPressEventArgs args)
    {
        //common.Writelog("OnButtonPressEvent");
    }

    protected void OnButtonReleaseEvent(object o, ButtonReleaseEventArgs args)
    {
        //common.Writelog("OnButtonReleaseEvent");
    }

    protected void OnChildNotified(object o, ChildNotifiedArgs args)
    {
        //common.Writelog("OnChildNotified");
    }

    protected void OnClientEvent(object o, ClientEventArgs args)
    {
        //common.Writelog("OnClientEvent");
    }

    protected void OnConfigureEvent(object o, ConfigureEventArgs args)
    {
        //common.Writelog("OnConfigureEvent");
    }

    protected void OnDestroyEvent(object o, DestroyEventArgs args)
    {
        //common.Writelog("OnDestroyEvent");
    }

    protected void OnDirectionChanged(object o, DirectionChangedArgs args)
    {
        //common.Writelog("OnDirectionChanged");
    }

    protected void OnDragBegin(object o, DragBeginArgs args)
    {
        //common.Writelog("OnDragBegin");
    }

    protected void OnDragDataDelete(object o, DragDataDeleteArgs args)
    {
        //common.Writelog("OnDragDataDelete");
    }

    protected void OnDragDataGet(object o, DragDataGetArgs args)
    {
        //common.Writelog("OnDragDataGet");
    }

    protected void OnDragDataReceived(object o, DragDataReceivedArgs args)
    {
        //common.Writelog("OnDragDataReceived");
    }

    protected void OnDragDrop(object o, DragDropArgs args)
    {
        //common.Writelog("OnDragDrop");
    }

    protected void OnDragEnd(object o, DragEndArgs args)
    {
        //common.Writelog("OnDragEnd");
    }

    protected void OnDragMotion(object o, DragMotionArgs args)
    {
        //common.Writelog("OnDragMotion");
    }

    protected void OnDragLeave(object o, DragLeaveArgs args)
    {
        //common.Writelog("OnDragLeave");
    }

    protected void OnEnterNotifyEvent(object o, EnterNotifyEventArgs args)
    {
        //common.Writelog("OnEnterNotifyEvent");
    }

    protected void OnFocused(object o, FocusedArgs args)
    {
        //common.Writelog("OnFocused");
    }

    protected void OnFocusGrabbed(object sender, EventArgs e)
    {
        //common.Writelog("OnFocusGrabbed");
    }

    protected void OnFocusInEvent(object o, FocusInEventArgs args)
    {
        //common.Writelog("OnFocusInEvent");
    }

    protected void OnFocusOutEvent(object o, FocusOutEventArgs args)
    {
        //common.Writelog("OnFocusOutEvent");
    }

    protected void OnGrabNotify(object o, GrabNotifyArgs args)
    {
        //common.Writelog("OnGrabNotify");
    }

    protected void OnHelpShown(object o, HelpShownArgs args)
    {
        //common.Writelog("OnHelpShown");
    }

    protected void OnHidden(object sender, EventArgs e)
    {
        //common.Writelog("OnHidden");
    }

    protected void OnHierarchyChanged(object o, HierarchyChangedArgs args)
    {
        //common.Writelog("OnHierarchyChanged");
    }

    protected void OnKeyPressEvent(object o, KeyPressEventArgs args)
    {
        //common.Writelog("OnKeyPressEvent");
    }

    protected void OnKeyReleaseEvent(object o, KeyReleaseEventArgs args)
    {
        //common.Writelog("OnKeyReleaseEvent");
    }

    protected void OnLeaveNotifyEvent(object o, LeaveNotifyEventArgs args)
    {
        //common.Writelog("OnLeaveNotifyEvent");
    }

    protected void OnMapped(object sender, EventArgs e)
    {
        //common.Writelog("OnMapped");
    }

    protected void OnMnemonicActivated(object o, MnemonicActivatedArgs args)
    {
        //common.Writelog("OnMnemonicActivated");
    }

    protected void OnMotionNotifyEvent(object o, MotionNotifyEventArgs args)
    {
        //common.Writelog("OnMotionNotifyEvent");
    }

    protected void OnNoExposeEvent(object o, NoExposeEventArgs args)
    {
        //common.Writelog("OnNoExposeEvent");
    }

    protected void OnParentSet(object o, ParentSetArgs args)
    {
        //common.Writelog("OnParentSet");
    }

    protected void OnPopupMenu(object o, PopupMenuArgs args)
    {
        //common.Writelog("OnPopupMenu");
    }

    protected void OnPropertyNotifyEvent(object o, PropertyNotifyEventArgs args)
    {
        //common.Writelog("OnPropertyNotifyEvent :" + o.ToString());
    }

    protected void OnProximityInEvent(object o, ProximityInEventArgs args)
    {
        //common.Writelog("OnProximityInEvent");
    }

    protected void OnProximityOutEvent(object o, ProximityOutEventArgs args)
    {
        //common.Writelog("OnProximityOutEvent");
    }

    protected void OnRealized(object sender, EventArgs e)
    {
        //common.Writelog("OnRealized");
    }

    protected void OnScreenChanged(object o, ScreenChangedArgs args)
    {
        //common.Writelog("OnScreenChanged");
    }

    protected void OnScrollEvent(object o, ScrollEventArgs args)
    {
        //common.Writelog("OnScrollEvent");
    }

    protected void OnSelectionClearEvent(object o, SelectionClearEventArgs args)
    {
        //common.Writelog("OnSelectionClearEvent");
    }

    protected void OnSelectionGet(object o, SelectionGetArgs args)
    {
        //common.Writelog("OnSelectionGet");
    }

    protected void OnSelectionNotifyEvent(object o, SelectionNotifyEventArgs args)
    {
        //common.Writelog("OnSelectionNotifyEvent");
    }

    protected void OnSelectionReceived(object o, SelectionReceivedArgs args)
    {
        //common.Writelog("OnSelectionReceived");
    }

    protected void OnSelectionRequestEvent(object o, SelectionRequestEventArgs args)
    {
        //common.Writelog("OnSelectionRequestEvent");
    }

    protected void OnShown(object sender, EventArgs e)
    {
        //common.Writelog("OnShown");
    }

    protected void OnSizeAllocated(object o, SizeAllocatedArgs args)
    {
        //common.Writelog("OnSizeAllocated");
    }

    protected void OnSizeRequested(object o, SizeRequestedArgs args)
    {
        //common.Writelog("OnSizeRequested");
    }

    protected void OnStateChanged(object o, StateChangedArgs args)
    {
        //common.Writelog("OnStateChanged");
    }

    protected void OnStyleSet(object o, StyleSetArgs args)
    {
        //common.Writelog("OnStyleSet");
    }

    protected void OnUnmapEvent(object o, UnmapEventArgs args)
    {
        //common.Writelog("OnUnmapEvent");
    }

    protected void OnUnmapped(object sender, EventArgs e)
    {
        //common.Writelog("OnUnmapped");
    }

    protected void OnUnrealized(object sender, EventArgs e)
    {
        //common.Writelog("OnUnrealized");
    }

    protected void OnVisibilityNotifyEvent(object o, VisibilityNotifyEventArgs args)
    {
        //common.Writelog("OnVisibilityNotifyEvent");
    }

    protected void OnWidgetEvent(object o, WidgetEventArgs args)
    {
        //common.Writelog("OnWidgetEvent : " + o.ToString());
    }

    protected void OnWidgetEventAfter(object o, WidgetEventAfterArgs args)
    {
        //common.Writelog("OnWidgetEventAfter");
    }

    protected void OnWindowStateEvent(object o, WindowStateEventArgs args)
    {
        //common.Writelog("OnWindowStateEvent");
    }
    #endregion
}
