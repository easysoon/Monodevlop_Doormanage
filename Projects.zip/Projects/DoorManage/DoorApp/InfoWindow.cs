﻿using System;
namespace DoorApp
{
    public partial class InfoWindow : Gtk.Dialog
    {
        public InfoWindow()
        {
            this.Build();
        }
    }
}
