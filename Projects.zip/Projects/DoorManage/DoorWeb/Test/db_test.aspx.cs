﻿using System;
using System.Web;
using System.Web.UI;


using System.Data;
using System.Text;
using System.Xml.Serialization;
using MySql.Data.MySqlClient;
using MySql.Data;
using System.Collections.Generic;

namespace DoorWeb
{

    public partial class db_test : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string error;
            string returnCode = "0000";

            string cmdText = "select * from db_doormanage.tbl_bbs where title like concat('%', @title, '%') ";
            Dictionary<string, object> cmdParam = new Dictionary<string, object>();
            cmdParam.Add("@title", "1");
            DataTable dataTable = dbcon.GetDataTable(cmdText, cmdParam, out returnCode, out error);
            foreach (DataRow dr in dataTable.Rows)
            {
                Response.Write(dr["title"].ToString() + "<br>");
            }
            Response.Write("<hr>");


            string sessionStr = common.GetSession("str");
            Response.Write(sessionStr);
            Session["str"] = sessionStr + "/";

            Response.Write("<hr>");

            //jsonhelper jsonhelper = new jsonhelper("");
        }
    }
}
