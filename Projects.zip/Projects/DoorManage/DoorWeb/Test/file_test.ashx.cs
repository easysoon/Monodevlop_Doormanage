﻿using System;
using System.Web;
using System.Web.UI;

namespace DoorWeb.Test
{

    public class file_test : System.Web.IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {

        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
