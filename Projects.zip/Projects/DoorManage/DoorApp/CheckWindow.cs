﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System.Timers;

namespace DoorApp
{


    public partial class CheckWindow : Gtk.Window
    {
        JObject appConfig = new JObject();
        delegate void SetTextCallback(string text);

        public CheckWindow() : base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }

        protected void OnEntCardKeyReleaseEvent(object o, Gtk.KeyReleaseEventArgs args)
        {
            if (args.Event.Key == Gdk.Key.KP_Enter)
            {
                if (string.IsNullOrWhiteSpace(ent_card.Text))
                {
                    return;
                }
                else
                {
                    CheckValid();
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
        }

        private void CheckValid()
        {
            try
            {

                string cardId = ent_card.Text.Trim();
                if (string.IsNullOrWhiteSpace(cardId))
                {
                    ent_card.Text = string.Empty;
                    return;
                }

                ent_card.IsEditable = false;
                Dictionary<string, string> httpParams = new Dictionary<string, string>();
                string error = string.Empty;

                httpParams.Add("type", "CHECK");
                JObject jObject = new JObject();
                jObject.Add("GI", common.GetStrVal(appConfig.Property("GI").Value));
                jObject.Add("SEQ", cardId);
                jObject.Add("IO", "IOA"); //입장 하드코딩
                httpParams.Add("DATA", jObject.ToString());

                string tmpReturn = common.GetHttpResponse(httpParams, out error);
                if (!string.IsNullOrEmpty(error)) throw new Exception(error);

                JObject jObjectReturn = JObject.Parse(tmpReturn);
                string valid = string.Empty;
                if (common.GetStrVal(jObjectReturn["DATA"]["CODE"]) == "0000")
                {
                    valid = common.GetStrVal(jObjectReturn["DATA"]["PERSONINFO"][0]["VALID"]);
                    if (valid == "VRA") lbl_valid.Text = "통과";
                    else lbl_valid.Text = "거부";
                    img_picture.File = common.DownLoadFile(cardId);
                    lbl_name.Text = common.GetStrVal(jObjectReturn["DATA"]["PERSONINFO"][0]["OUTER_NAME"]);
                    lbl_time.Text = common.GetStrVal(jObjectReturn["DATA"]["PERSONINFO"][0]["TIME"]);
                }
                else
                {
                    valid = "VRB";
                    lbl_valid.Text = common.GetStrVal(jObjectReturn["ERROR"]);
                }
                common.PlayValidSound(valid);
            }
            catch (Exception ex)
            {
                lbl_valid.Text = ex.Message;
                common.PlayValidSound("VRB");
            }

            timer.Start();

        }

        private void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                Gtk.Application.Invoke(delegate {
                    lbl_name.Text = "";
                    lbl_time.Text = "";
                    lbl_valid.Text = "";
                    ent_card.IsEditable = true;
                    ent_card.Text = "";
                    img_picture.File = common.AppSettingsGet("FileSavePath") + "/blank.png";
                });
            }
            catch (Exception ex)
            {
                common.Writelog(ex.Message);
            }
        }

        private static  System.Timers.Timer timer = new System.Timers.Timer();

        protected void OnMapEvent(object o, Gtk.MapEventArgs args)
        {
            appConfig = common.ReadConfig();
            timer.Interval = 1000; // 1 시간
            timer.AutoReset = false;
            timer.Elapsed += new ElapsedEventHandler(timer_Elapsed);
        }

        protected void OnEntCardTextInserted(object o, Gtk.TextInsertedArgs args)
        {

        }

        protected void OnBtnClearClicked(object sender, EventArgs e)
        {
        }

        private void SetControl(string values)
        {      
        }

        protected void OnEntCardClientEvent(object o, Gtk.ClientEventArgs args)
        {
        }

        protected void OnExposeEvent(object o, Gtk.ExposeEventArgs args)
        {
        }



        protected void OnEntCardChanged(object sender, EventArgs e)
        {
        }

        protected void OnEntCardEditingDone(object sender, EventArgs e)
        {
        }

        protected void OnEntCardInsertAtCursor(object o, Gtk.InsertAtCursorArgs args)
        {
        }


    }
}