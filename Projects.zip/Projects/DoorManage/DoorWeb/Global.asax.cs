﻿using System.Web;

namespace DoorWeb
{
    public class Global : HttpApplication
    {
        protected void Application_Start()
        {
        }
    }
}
