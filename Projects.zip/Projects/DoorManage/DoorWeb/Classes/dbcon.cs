﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Configuration;


namespace DoorWeb
{

    public class dbcon
    {
        private static string connectionString = common.AppSettingsGet("connectionstring");

        public dbcon() { }

        public static int ExecuteNonQuery(string cmdText, Dictionary<string, object> cmdParam, out string returnCode, out string error)
        {
            error = string.Empty;
            returnCode = "0000";
            int result = 0;//삽입시 발생하는 new index

            MySqlConnection conn = new MySqlConnection();//Please don't assign it as Global variable.

            try
            {
                conn = new MySqlConnection(connectionString);
                conn.Open();
                using (DbTransaction tran = conn.BeginTransaction())
                {
                    MySqlCommand cmd = new MySqlCommand(cmdText, conn);
                    foreach (KeyValuePair<string, object> pair in cmdParam)
                    {
                        cmd.Parameters.AddWithValue(pair.Key, pair.Value);
                    }
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        cmd.CommandText = "Select @@Identity";
                        result = int.Parse(common.GetStrVal(cmd.ExecuteScalar()));
                        tran.Commit();
                    }
                    else
                    {
                        tran.Rollback();
                        error = "저징된 내용이 없습니다.";
                        returnCode = "FAIL";
                    }
                }
            }
            catch (Exception ex)
            {
                returnCode = "FAIL";
                error = ex.Message;
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
            return result;
        }

        public static DataTable GetDataTable(string cmdText, Dictionary<string, object> cmdParam, out string returnCode, out string error)
        {
            error = string.Empty;
            returnCode = "0000";
            DataTable dataTable = new DataTable();
            MySqlConnection conn = new MySqlConnection();//Please don't assign it as Global variable.

            try
            {

                conn = new MySqlConnection(connectionString);
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(cmdText, conn);
                    foreach (KeyValuePair<string, object> pair in cmdParam)
                    {
                        cmd.Parameters.AddWithValue(pair.Key, pair.Value);
                    }
                    cmd.ExecuteNonQuery();
                    new MySqlDataAdapter(cmd).Fill(dataTable);

                }
            }
            catch (Exception ex)
            {
                returnCode = "FAIL";
                error = ex.Message;
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
            return dataTable;
        }
    }
}