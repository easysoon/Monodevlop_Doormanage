﻿using System;
using System.Web;
using System.Web.SessionState;
using System.Collections.Generic;
using System.Data;
using Newtonsoft.Json.Linq;

namespace DoorWeb.In_If
{

    public class index : System.Web.IHttpHandler, IRequiresSessionState
    {
        public bool IsReusable { get { return false; } }

        public void ProcessRequest(HttpContext context)
        {
            string result = string.Empty;
            if (common.CheckReferer()) 
                result = MainFunction();
            context.Response.ContentType = "text/plain";
            context.Response.Write(result);     

            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        private string MainFunction()
        {
            string data = common.GetForm("DATA");
            JObject jObject = JObject.Parse(data);

            switch (common.GetStrVal(jObject["type"]))
            {
                case "CHECKEMAIL":
                    CheckEmail(jObject);
                    break;
                case "JOIN":
                    SaveInfo(jObject);
                    break;
                case "LOGIN":
                    LoginProcess(jObject);
                    break;
                case "LOGOUT":
                    LogoutProcess(jObject);
                    break;
                case "TIME":
                    CheckTime(jObject);
                    break;
                case "FIND":
                    FindPassword(jObject);
                    break;
                case "APPLY":
                    ApplyEnter(jObject);
                    break;
                case "HISTORY":
                    ApplyHistory(jObject);
                    break;
                case "NOTICE":
                    GetNotice(jObject);
                    break;
            }

            return jObject["RETURNDATA"].ToString();
        }

        private void SaveInfo(JObject jObject)
        {
            string error = string.Empty;
            string returnCode = "0000";
            string cmdText
            = "INSERT INTO TBL_OUTER (OUTER_EMAIL, OUTER_PASSWORD, OUTER_NAME, OUTER_STATUS) "
            + "VALUES "
            + "(@OUTER_EMAIL, @OUTER_PASSWORD, @OUTER_NAME, @OUTER_STATUS);";
            Dictionary<string, object> cmdParam = new Dictionary<string, object>();
            cmdParam.Add("@OUTER_EMAIL", common.GetStrVal(jObject["OUTER_EMAIL"]) );
            cmdParam.Add("@OUTER_NAME", common.GetStrVal(jObject["OUTER_NAME"])); 
            cmdParam.Add("@OUTER_PASSWORD", common.GetStrVal(jObject["PASSWORD"])); 
            cmdParam.Add("@OUTER_STATUS", "OSA");
            int dbResult = dbcon.ExecuteNonQuery(cmdText, cmdParam, out returnCode, out error);
 
            jObject.Add( new JProperty("RETURNDATA",  new JObject(
            new JProperty("DATA",
                new JObject(
                    new JProperty("ERROR", error),
                    new JProperty("CODE", returnCode)
                    )))));
        }

        private void ApplyEnter(JObject jObject)
        {
            string error = string.Empty;
            string returnCode = "0000";
            string savedFilename = string.Empty;

            if (HttpContext.Current.Request.Files.Count > 0)
            {
                HttpPostedFile httpPostedFile = HttpContext.Current.Request.Files["file_apply_picture"];

                if (!common.SaveUploadFile(httpPostedFile, out savedFilename, out error))
                {
                    returnCode = "FAIL";
                }
                else
                {
                    string cmdText
                    = "INSERT INTO TBL_ENTER_APPLY"
                    + "(OUTER_EMAIL, REASON, PICTURE_SAVED_NAME, VALID_BEGIN, VALID_END, JUDGE_EMP,  ENTER_APPLY_STATUS) "
                    + "VALUES "
                    + "(@OUTER_EMAIL, @REASON, @PICTURE_SAVED_NAME, @VALID_BEGIN, @VALID_END, @JUDGE_EMP, 'ASA'); ";
                    Dictionary<string, object> cmdParam = new Dictionary<string, object>();
                    cmdParam.Add("@OUTER_EMAIL", common.GetSession("OUTER_EMAIL"));
                    cmdParam.Add("@REASON", common.GetStrVal(jObject["REASON"]));
                    cmdParam.Add("@PICTURE_SAVED_NAME", savedFilename);
                    cmdParam.Add("@VALID_BEGIN", common.GetStrVal(jObject["VALID_BEGIN"]));
                    cmdParam.Add("@VALID_END", common.GetStrVal(jObject["VALID_END"]));
                    cmdParam.Add("@JUDGE_EMP", common.AppSettingsGet("DoorManageAdmin"));
                    int newIndex = dbcon.ExecuteNonQuery(cmdText, cmdParam, out returnCode, out error);

                    if (returnCode != "0000") returnCode = "FAIL";
                    else if (newIndex == 0) returnCode = "FAIL";
                    else
                    {
                        string emailSubject = "[출입신청] " + common.GetSession("OUTER_NAME") + "님이 접수하셨습니다.";
                        string emailContent = "출입신청<br>"
                        + "접수자 성명: " + common.GetSession("OUTER_NAME") + "<br>"
                        + "이메일: " + common.GetSession("OUTER_EMAIL") + "<br><br>"
                        + "<img src='" + common.AppSettingsGet("InnerWebAddress") + "/In_If/file_transfer.ashx?type=pic&seq=" + newIndex + "'/><br>"
                        + "사유 : " + common.GetStrVal(jObject["REASON"]) + "<br>"
                        + "출입 시작 : " + common.GetStrVal(jObject["VALID_BEGIN"]) + "<br>"
                        + "출입 종료 : " + common.GetStrVal(jObject["VALID_END"]) + "<br><br>"
                        + "<table><tr><td colspan='2'>승인하시겠습니까?</td><tr>"
                        + "<tr><td width='100'><a href='" + common.AppSettingsGet("InnerWebAddress") + "/judge.aspx?judge=Y&seq=" + newIndex + "'>승인</a></td>"
                        + "<td width='100'><a href='" + common.AppSettingsGet("InnerWebAddress") + "/judge.aspx?judge=N&seq=" + newIndex + "'>반려</a></td></tr></table>";
                        smtp.EmailSend(common.AppSettingsGet("DoorManageAdmin"), emailSubject, emailContent, out error, out returnCode);
                    }
                }
            }

            jObject.Add(new JProperty("RETURNDATA", new JObject(
            new JProperty("DATA",
                new JObject(
                    new JProperty("ERROR", error),
                    new JProperty("CODE", returnCode))))));

        }


        private void FindPassword(JObject jObject)
        {
            string error = string.Empty;
            string returnCode = "0000";
            string cmdText
            = "SELECT OUTER_EMAIL, OUTER_PASSWORD, OUTER_NAME "
            + "FROM TBL_OUTER T1 "
            + "WHERE T1.OUTER_EMAIL = @EMAIL ";
            Dictionary<string, object> cmdParam = new Dictionary<string, object>();
            cmdParam.Add("@EMAIL", common.GetStrVal(jObject["OUTER_EMAIL"]));
            DataTable dataTable = dbcon.GetDataTable(cmdText, cmdParam, out returnCode, out error);

            if (returnCode != "0000") returnCode = "FAIL";
            else if (!dataTable.Rows.Count.Equals(1)) returnCode = "FAIL";
            else {
                string emailContent = "현재 비밀번호 : " + common.GetStrVal(dataTable.Rows[0]["OUTER_PASSWORD"]);
                smtp.EmailSend(common.GetStrVal(dataTable.Rows[0]["OUTER_EMAIL"]), "출입관리시스템 비밀번호를 알려드립니다.", emailContent, out error, out returnCode);
                }

            try
            {
                jObject.Add(new JProperty("RETURNDATA", new JObject(
                new JProperty("DATA",
                    new JObject(
                        new JProperty("ERROR", error),
                        new JProperty("CODE", returnCode))))));
            }
            catch { }
        }

        private void CheckTime(JObject jObject)
        {
            string error = string.Empty;
            string returnCode = "0000";
            string cmdText
            = "SELECT DATE_FORMAT(NOW(), '%Y-%m-%d') AS 'DBDATE',DATE_FORMAT(NOW(), ' %H:%I:%S') AS 'DBTIME' ";
            Dictionary<string, object> cmdParam = new Dictionary<string, object>();
            DataTable dataTable = dbcon.GetDataTable(cmdText, cmdParam, out returnCode, out error);

            if (returnCode != "0000") returnCode = "FAIL";

            JArray jArray = new JArray();

            foreach (DataRow datarow in dataTable.Rows)
            {
                JObject jobTmp = new JObject
                         (
                         new JProperty("DBDATE", common.GetStrVal(datarow["DBDATE"])),
                         new JProperty("DBTIME", common.GetStrVal(datarow["DBTIME"]))
                         );
                jArray.Add(jobTmp);
            }
            jObject.Add(new JProperty("RETURNDATA", new JObject(
            new JProperty("DATA",
                new JObject(
                    new JProperty("ERROR", error),
                    new JProperty("CODE", returnCode),
                    new JProperty("TIME", jArray))))));

        }

        private void ApplyHistory(JObject jObject)
        {
            string error = string.Empty;
            string returnCode = "0000";
            string cmdText
                = "CREATE TEMPORARY TABLE IF NOT EXISTS "
                + "temp_table "
                + "( "
                + "ROWNUM INT NOT NULL AUTO_INCREMENT, "
                + "REASON TINYTEXT NOT NULL, " 
                + "VALID_BEGIN DATE NOT NULL,"
                + "VALID_END DATE NOT NULL,"
                + "MODIFY_DATE DATETIME NOT NULL,"
                + "APPLY_STATUS VARCHAR(50) NOT NULL,"
                + "PRIMARY KEY(ROWNUM) "
                + ") "
                + "SELECT REASON, VALID_BEGIN, VALID_END, MODIFY_DATE, T2.DETAIL_NAME AS 'APPLY_STATUS' "
                + "FROM TBL_ENTER_APPLY T1 "
                + "JOIN TBL_CODE T2 ON T1.ENTER_APPLY_STATUS = T2.DETAIL AND T2.GROUP = 'AS' "
                + "WHERE T1.OUTER_EMAIL = @OUTER_EMAIL "
                + "ORDER BY T1.MODIFY_DATE DESC; "
                + "SELECT * FROM TEMP_TABLE;";
            Dictionary<string, object> cmdParam = new Dictionary<string, object>();
            cmdParam.Add("@OUTER_EMAIL", common.GetSession("OUTER_EMAIL"));
            DataTable dataTable = dbcon.GetDataTable(cmdText, cmdParam, out returnCode, out error);

            if (!string.IsNullOrEmpty(error))
            {
                returnCode = "FAIL";
            }
            try
            {
                JArray jArray = new JArray();

                foreach (DataRow datarow in dataTable.Rows)
                {
                    string validBegin = DateTime.Parse(common.GetStrVal(datarow["VALID_BEGIN"])).ToShortDateString();
                    string validEnd = DateTime.Parse(common.GetStrVal(datarow["VALID_END"])).ToShortDateString();
                    JObject jobTmp = new JObject
                         (
                         new JProperty("ROWNUM", common.GetStrVal(datarow["ROWNUM"])),
                         new JProperty("VALID_BEGIN", validBegin),
                         new JProperty("VALID_END", validEnd),
                         new JProperty("REASON", common.GetStrVal(datarow["REASON"])),
                         new JProperty("MODIFY_DATE", common.GetStrVal(datarow["MODIFY_DATE"])),
                         new JProperty("APPLY_STATUS", common.GetStrVal(datarow["APPLY_STATUS"]))
                         );
                    jArray.Add(jobTmp);
                }
                jObject.Add(new JProperty("RETURNDATA", new JObject(
                new JProperty("DATA",
                    new JObject(
                        new JProperty("ERROR", error),
                        new JProperty("CODE", returnCode),
                        new JProperty("HISTORY", jArray))))));
            }
            catch { }
        }

        private void LogoutProcess(JObject jObject)
        {
            string error = string.Empty;
            string returnCode = "0000";
            try
            {
                HttpContext.Current.Session.Abandon();
                JArray jArray = new JArray();

                jObject.Add(new JProperty("RETURNDATA", new JObject(
                new JProperty("DATA",
                    new JObject(
                        new JProperty("ERROR", error),
                        new JProperty("CODE", returnCode))))));
            }
            catch { }
        }

        private void LoginProcess(JObject jObject)
        {
            JArray jArray = new JArray();
            string error = string.Empty;
            string returnCode = "0000";
            string cmdText
            = "SELECT  OUTER_EMAIL, OUTER_PASSWORD, OUTER_NAME, OUTER_STATUS "
            + "FROM TBL_OUTER T1 "
            + "WHERE T1.OUTER_EMAIL = @OUTER_EMAIL ";
            Dictionary<string, object> cmdParam = new Dictionary<string, object>();
            cmdParam.Add("@OUTER_EMAIL", common.GetStrVal(jObject["OUTER_EMAIL"]));
            DataTable dataTable = dbcon.GetDataTable(cmdText, cmdParam, out returnCode, out error);

            if (returnCode != "0000") returnCode = "FAIL";
            else if (dataTable.Rows.Count != 1)
            {//0=미가입. 1초과=해킹.
                error = "이메일주소가 존재하지 않습니다.";
                returnCode = "FAIL";
            }
            else if (common.GetStrVal(dataTable.Rows[0]["OUTER_PASSWORD"]) != common.GetStrVal(jObject["PASSWORD"].ToString()))
            {
                error = "비밀번호가 불일치합니다.";
                returnCode = "FAIL";
            }
            else
            {
                HttpContext.Current.Session["OUTER_EMAIL"] = common.GetStrVal(dataTable.Rows[0]["OUTER_EMAIL"]);
                HttpContext.Current.Session["OUTER_NAME"] = common.GetStrVal(dataTable.Rows[0]["OUTER_NAME"]);
                HttpContext.Current.Session["OUTER_STATUS"] = common.GetStrVal(dataTable.Rows[0]["OUTER_STATUS"]);

                foreach (DataRow datarow in dataTable.Rows)
                {
                    JObject jobTmp = new JObject
                             (
                             new JProperty("NAME", common.GetStrVal(datarow["OUTER_NAME"])),
                             new JProperty("EMAIL", common.GetStrVal(datarow["OUTER_EMAIL"]))
                             );
                    jArray.Add(jobTmp);
                }
            }
            jObject.Add(new JProperty("RETURNDATA", new JObject(
                new JProperty("DATA",
                    new JObject(
                        new JProperty("ERROR", error),
                        new JProperty("CODE", returnCode),
                        new JProperty("USERINFO", jArray))))));
        }

        private void CheckEmail(JObject jObject)
        {
            string error = string.Empty;
            string returnCode = "0000";
            string cmdText
            = "SELECT COUNT(1) JOINCOUNT "
            + "FROM TBL_OUTER T1 "
            + "WHERE T1.OUTER_EMAIL = @EMAIL ";
            Dictionary<string, object> cmdParam = new Dictionary<string, object>();
            cmdParam.Add("@email", common.GetStrVal(jObject["OUTER_EMAIL"]));
            DataTable dataTable = dbcon.GetDataTable(cmdText, cmdParam, out returnCode, out error);

            if (returnCode != "0000") returnCode = "FAIL";
            else if (common.GetStrVal(dataTable.Rows[0]["JOINCOUNT"]) != "0")
            {
                returnCode = "FAIL";
                error = "이미 가입한 이메일입니다.";
            }

            jObject.Add(new JProperty("RETURNDATA", new JObject(
            new JProperty("DATA",
                new JObject(
                    new JProperty("ERROR", error),
                    new JProperty("CODE", returnCode)
                    )
                ))));
        }


        private void GetNotice(JObject jObject)
        {
            JArray jArray = new JArray();
            string error = string.Empty;
            string returnCode = "0000";
            string cmdText
                = "SELECT TITLE, CONTENT " 
                + "FROM TBL_BBS " 
                + "ORDER BY SEQ DESC " 
                + "LIMIT 0,1 ";
            Dictionary<string, object> cmdParam = new Dictionary<string, object>();
            DataTable dataTable = dbcon.GetDataTable(cmdText, cmdParam, out returnCode, out error);

            if (returnCode != "0000") returnCode = "FAIL";
            else if (dataTable.Rows.Count == 0)
            {
                error = "공지사항이 없습니다.";
                returnCode = "FAIL";
            }
            else
            {
                foreach (DataRow datarow in dataTable.Rows)
                {
                    JObject jobTmp = new JObject
                             (
                             new JProperty("TITLE", common.GetStrVal(datarow["TITLE"])),
                             new JProperty("CONTENT", common.GetStrVal(datarow["CONTENT"]))
                             );
                    jArray.Add(jobTmp);
                }
            }

            jObject.Add(new JProperty("RETURNDATA", new JObject(
            new JProperty("DATA",
                new JObject(
                    new JProperty("ERROR", error),
                    new JProperty("CODE", returnCode),
                    new JProperty("NOTICE", jArray))))));
        }
    }
}