﻿using System;
using System.Net.Mail;
using System.Configuration;

namespace DoorWeb
{
    public class smtp
    {
        public smtp()
        {
        }

        public static void EmailSend(string mail_to, string subject, string contents, out string error, out string returnCode)
        {
            error = string.Empty;
            returnCode = "0000";
            try
            {
                string smtpId = common.AppSettingsGet("SmtpId");
                string smtpPassword = common.AppSettingsGet("SmtpPassword");
                int smtpPort = int.Parse(common.AppSettingsGet("SmtpPort"));
                string smtpHost = common.AppSettingsGet("SmtpHost");
                bool smtpSsl = bool.Parse(common.AppSettingsGet("SmtpSsl"));
                string smtpSender = common.AppSettingsGet("SmtpSender");
                MailMessage msg = new MailMessage();
                msg.To.Add(mail_to);
                msg.From = new MailAddress(smtpSender, smtpSender, System.Text.Encoding.UTF8);
                msg.Subject = subject;
                msg.SubjectEncoding = System.Text.Encoding.UTF8;
                msg.Body = contents;
                msg.BodyEncoding = System.Text.Encoding.UTF8;
                msg.IsBodyHtml = true;
                msg.Priority = MailPriority.Normal;

                SmtpClient client = new SmtpClient();
                client.Credentials = new System.Net.NetworkCredential(smtpId, smtpPassword);
                client.Port = smtpPort;
                client.Host = smtpHost;
                client.EnableSsl = smtpSsl;

                client.Send(msg);
            }
            catch (Exception ex)
            {
                error = ex.Message;
                returnCode = "FAIL";
            }
        }
    }
}
