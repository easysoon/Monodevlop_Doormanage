﻿using System;
using System.IO;

using System.Text;
using System.Configuration;
using System.Net;
using System.Collections.Generic;
using System.Collections.Specialized;
using Newtonsoft.Json.Linq;



public class common
{
    public common() { }

    /// <summary>
    /// get string value for any object
    /// </summary>
    /// <param name="objValue">any object</param>
    /// <param name="sOption">default value for blank string</param>
    /// <returns>string result. blank for converting error</returns>
    public static string GetStrVal(object value, string option = "")
    {
        string result = string.Empty;

        try
        {
            result = value.ToString().Trim();
        }
        catch (Exception ex)
        {
            string error = ex.Message;
        }

        if (result == string.Empty)
        {
            if (option.Equals("HTML"))
            {
                result = "&nbsp;";
            }
            else if (option.Equals("PAGE"))
            {
                result = "1";
            }
            else
            {
                result = option;
            }
        }

        return result;
    }

    public static void PlayValidSound(string soundKind)
    {

        switch (soundKind)
        {
            case "VRA": //허가
                System.Media.SystemSounds.Beep.Play();
                break;
            default: //불가
                using (System.Media.SoundPlayer validSound = new System.Media.SoundPlayer())
                {
                    validSound.SoundLocation = AppSettingsGet("FileSavePath") + "/Valid_Fail.wav";
                    validSound.Play();
                    validSound.Dispose();
                }
                break;
        }
    }


    public static string GetHttpResponse(Dictionary<string, string> httpParams, out string error)
    {
        string result = string.Empty;
        string url = common.AppSettingsGet("IfUrl");
        error = string.Empty;

        try
        {
            using (var client = new WebClient())
            {
                NameValueCollection values = new NameValueCollection();

                foreach (KeyValuePair<string, string> pair in httpParams)
                {
                    values[pair.Key] = pair.Value;
                }
                byte[] response = client.UploadValues(url, values);
                result = Encoding.Default.GetString(response);
            }
        }
        catch (Exception ex)
        {
            error = ex.Message;
        }
        return result;
    }

public static string AppSettingsGet(string appSettingskey)
    {
        string result = string.Empty;
        try
        {
            result = ConfigurationManager.AppSettings.Get(appSettingskey);
        }
        catch { }
        return result;
    }

    public static void Writelog(string str_message)
    {
        try
        {
            string savePathName = AppSettingsGet("FileSavePath") + "/AppLog/" + DateTime.Now.ToString("yyyy") + "/" + DateTime.Now.ToString("MM");
            DirectoryInfo directoryInfo = new DirectoryInfo(savePathName);
            if (!directoryInfo.Exists) directoryInfo.Create();
            FileStream fs = new FileStream(savePathName + "/" + DateTime.Now.Day.ToString() + ".Log", FileMode.Append);
            StreamWriter w = new StreamWriter(fs, System.Text.Encoding.UTF8);
            w.BaseStream.Seek(0, SeekOrigin.End);
            w.WriteLine(str_message);
            w.Flush();
            w.Close();
        }
        catch { }
    }

    public static void WriteConfig(JObject jObject)
    {
        try
        {
            string savePath = AppSettingsGet("FileSavePath");
            string saveName = AppSettingsGet("FileSavePath") + "/Config";
            DirectoryInfo directoryInfo = new DirectoryInfo(savePath);
            FileInfo fileInfo = new FileInfo(saveName);

            if (!directoryInfo.Exists) directoryInfo.Create();
            if (fileInfo.Exists) fileInfo.Delete();

            FileStream fs = fileInfo.OpenWrite();
            StreamWriter w = new StreamWriter(fs, System.Text.Encoding.UTF8);
            w.BaseStream.Seek(0, SeekOrigin.End);
            w.WriteLine(jObject.ToString());
            w.Flush();
            w.Close();
        }
        catch { }
    }

    public static JObject ReadConfig()
    {
        string saveName = AppSettingsGet("FileSavePath") + "/Config";
        JObject result = new JObject();
        try
        {
            result = JObject.Parse(File.ReadAllText(saveName));
        }
        catch { }
        return result;

    }

    public static string DownLoadFile(string seq)
    {
        string requestUrl = AppSettingsGet("FileUrl") + "?type=pic&seq=" + seq;

        WebClient webClient = new WebClient();
        Byte[] webByte = webClient.DownloadData(requestUrl);

        string downName = AppSettingsGet("FileSavePath") + "/tmpDownload";
        string serveName = AppSettingsGet("FileSavePath") + "/tmpServe";

        //기본적으로 덮어쓰기를 하지만, 일부러 삭제합니다.
        FileInfo downFileInfo = new FileInfo(downName);
        FileInfo serveFileInfo = new FileInfo(serveName);
        if (downFileInfo.Exists) downFileInfo.Delete();
        if (serveFileInfo.Exists) serveFileInfo.Delete();

        StreamWriter streamWriter = new StreamWriter(downName);
        BinaryWriter binaryWriter = new BinaryWriter(streamWriter.BaseStream);
        binaryWriter.Write(webByte);
        binaryWriter.Close();

        if (webByte.Length == 0) serveName = AppSettingsGet("FileSavePath") + "/blank.png";
        else
        {
            System.Drawing.Image image = System.Drawing.Image.FromFile(downName);
            System.Drawing.Image thumbImage = image.GetThumbnailImage(200, 200, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
            thumbImage.Save(serveName);
        }

        return serveName;
    }

    public static bool ThumbnailCallback()
    {
        return true;
    }
}