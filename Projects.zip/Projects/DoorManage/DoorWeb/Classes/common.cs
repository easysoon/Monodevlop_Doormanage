﻿using System;
using System.Web;
using System.IO;
using System.Xml;
using System.Text;
using System.Data;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

using System.Configuration;


namespace DoorWeb
{
    public class common
    {
        public common(){}

        /// <summary>
        /// check reference host
        /// </summary>
        /// <returns>true : success, false : fail</returns>
        public static bool CheckReferer()
        {
            bool result = true;

            string referer = GetStrVal(HttpContext.Current.Request.ServerVariables["HTTP_REFERER"]).ToLower();
            string host = GetStrVal(HttpContext.Current.Request.ServerVariables["HTTP_HOST"]).ToLower();

            if (!referer.Contains(host))
            {
                result = false;
            }

            return result;
        }

        /// <summary>
        /// get session
        /// </summary>
        /// <param name="name">session name</param>
        /// <returns></returns>
        public static string GetSession(string name)
        {
            string result = string.Empty;

            if ((HttpContext.Current != null) && (HttpContext.Current.Session != null) && (HttpContext.Current.Session[name] != null))
            {
                result = HttpContext.Current.Session[name].ToString();
            }

            return result;
        }

        /// <summary>
        /// get querystring
        /// </summary>
        /// <param name="name">querystring name</param>
        /// <param name="defaultValue">option value</param>
        /// <returns></returns>
        public static string GetQueryString(string name, string value = "")
        {
            return GetStrVal(HttpContext.Current.Request.QueryString[name], value);
        }

        /// <summary>
        /// get form
        /// </summary>
        /// <param name="name">form name</param>
        /// <param name="defaultValue">option value</param>
        /// <returns></returns>
        public static string GetForm(string name, string value = "")
        {
            return GetStrVal(HttpContext.Current.Request.Form[name], value);
        }

        /// <summary>
        /// get string value for any object
        /// </summary>
        /// <param name="objValue">any object</param>
        /// <param name="sOption">default value for blank string</param>
        /// <returns>string result. blank for converting error</returns>
        public static string GetStrVal(object value, string option = "")
        {
            string result = string.Empty;

            try
            {
                result = value.ToString().Trim();
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }

            if (result == string.Empty)
            {
                if (option.Equals("HTML"))
                {
                    result = "&nbsp;";
                }
                else if (option.Equals("PAGE"))
                {
                    result = "1";
                }
                else
                {
                    result = option;
                }
            }

            return result;
        }

        /// <summary>
        /// get htts response for the request (url + querystring only)
        /// </summary>
        /// <param name="sUrl">url with query string</param>
        /// <returns>http response string</returns>
        public static string GetHttsRespose(string url)
        {
            string result = string.Empty;

            try
            {
                System.Net.WebRequest req = System.Net.WebRequest.Create(url);
                //req.Proxy = new System.Net.WebProxy(ProxyString, true); //true means no proxy
                System.Net.WebResponse resp = req.GetResponse();
                System.IO.StreamReader sr = new System.IO.StreamReader(resp.GetResponseStream());

                result = sr.ReadToEnd().Trim();
            }
            catch (Exception ex)
            {
                result = ex.Message;
            }

            return result;
        }

        public static string AppSettingsGet(string appSettingskey)
        {
            string result = string.Empty;
            try
            {
                result = ConfigurationManager.AppSettings.Get(appSettingskey);
            }
            catch { }
            return result;
        }

        public static bool SaveUploadFile(HttpPostedFile file, out string fileName, out string error)
        {
            error = string.Empty;
            fileName = string.Empty;
            bool result = true;

            try
            {
                #region variables setting
                int fileSizeLimit = int.Parse(AppSettingsGet("FileSizeLimit"));
                string savePath = string.Empty;
                string saveSubPath = string.Empty;
                bool fileOverwrite = bool.Parse(AppSettingsGet("FileOverwrite"));

                string uploadfilename = Guid.NewGuid().ToString().Replace("-", "");
                string filePathFormat = AppSettingsGet("FilePathFormat");
                string[] tmpArray = filePathFormat.Split('/');
                for (int i1 = 0; i1 < tmpArray.Length; i1++)
                {
                    saveSubPath += "/" + string.Format("{0:" + tmpArray[i1] + "}", DateTime.Now);
                }
                savePath = AppSettingsGet("FileSavePath") + saveSubPath;
                #endregion

                #region variables checking
                if (!file.ContentType.Contains("image")) throw new Exception("이미지 파일만 업로드 가능합니다.");
                if (file.ContentLength > fileSizeLimit) throw new Exception("이미지 파일이 너무 큽니다. \n제한 : " + fileSizeLimit.ToString() + "Byte");
                if (!Directory.Exists(savePath)) Directory.CreateDirectory(savePath);
                #endregion

                #region main code
                if (System.IO.File.Exists(System.IO.Path.Combine(savePath, uploadfilename)))
                {
                    if (fileOverwrite)
                    {
                        file.SaveAs(System.IO.Path.Combine(savePath, uploadfilename));
                    }
                    else
                    {
                        while (true)
                        {
                            uploadfilename = Guid.NewGuid().ToString().Replace("-", "");
                            if (!System.IO.File.Exists(System.IO.Path.Combine(savePath, uploadfilename)))
                            {
                                file.SaveAs(System.IO.Path.Combine(savePath, uploadfilename));
                            }
                        }
                    }
                }
                else
                {
                    file.SaveAs(System.IO.Path.Combine(savePath, uploadfilename));
                }
                fileName = saveSubPath + "/" + uploadfilename;
                #endregion
            }
            catch (Exception ex)
            {
                error = ex.Message;
                result = false;
            }
            return result;
        }

        #region Thumbnail
        public static string GetThumbnail(string pathOriginal, int width, int height, out string error)
        {
            string result = pathOriginal + "_THUMB";
            error = string.Empty;
            try
            {
                bool overWrite = bool.Parse(AppSettingsGet("FileOverwrite"));
                FileInfo fiOriginal = new FileInfo(pathOriginal);
                FileInfo fiThumb = new FileInfo(result);

                if (!fiOriginal.Exists)
                {
                    error = "Source file not exists";
                    return string.Empty;
                }
                else if (fiThumb.Exists && !overWrite) //덮어쓰기 안할꺼면, 리턴
                {
                    error = "Cannot overwrite.";
                    return string.Empty; 
                }
                else if (fiThumb.Exists && overWrite) //덮어쓰기 할꺼면, 타겟 삭제
                {
                    fiThumb.Delete();
                }

                System.Drawing.Image image = System.Drawing.Image.FromFile(pathOriginal);
                System.Drawing.Image thumbImage = image.GetThumbnailImage(width, height, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                //MemoryStream imageStream = new MemoryStream();
                thumbImage.Save(result);
                image.Dispose();
            }
            catch (Exception ex)
            {
                error = ex.Message;
            }
            return result;
        }

        public static bool ThumbnailCallback()
        {
            return true;
        }

        public static void Writelog(string str_message)
        {
            string savePathName = AppSettingsGet("FileSavePath") + "/WebLog/" + DateTime.Now.ToString("yyyy") + "/" + DateTime.Now.ToString("MM");
            DirectoryInfo directoryInfo = new DirectoryInfo(savePathName);
            if (!directoryInfo.Exists) directoryInfo.Create();
            FileStream fs = new FileStream(savePathName + "/" + DateTime.Now.Day.ToString() + ".Log", FileMode.Append);
            StreamWriter w = new StreamWriter(fs, System.Text.Encoding.UTF8);
            w.BaseStream.Seek(0, SeekOrigin.End);
            w.WriteLine(DateTime.Now.ToString() + " -- " + str_message);
            w.Flush();
            w.Close();
        }

        #endregion Thumbnail
    }
}