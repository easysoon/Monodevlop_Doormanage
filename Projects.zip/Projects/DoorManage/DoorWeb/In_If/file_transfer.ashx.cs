﻿using System;
using System.Web;
using System.Web.UI;

using System.Text;
using System.Collections.Generic;
using System.Data;
using System.IO;

namespace DoorWeb.In_If
{

    public class file_transfer : System.Web.IHttpHandler
    {

        public bool IsReusable
        {
            get { return false; }
        }

        public void ProcessRequest(HttpContext context)
        {
            MainFunction();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        private void MainFunction()
        {
            string type = common.GetQueryString("type");
            switch (type)
            {
                case "pic":
                    GetThumbNail();
                    break;
            }
        }


        private void GetThumbNail()
        {
            string reternCode = "0000";
            string error = string.Empty;
            string applySeq = common.GetQueryString("seq");
            string fileSavedName = string.Empty;
            string fileThumbName = string.Empty;
            Dictionary<string, object> cmdParam = new Dictionary<string, object>();
            cmdParam.Add("@SEQ", int.Parse(applySeq));
            string cmdText = "SELECT PICTURE_SAVED_NAME " +
                "FROM TBL_ENTER_APPLY " +
                "WHERE " +
                "SEQ = @SEQ ";
            DataTable dataTable = dbcon.GetDataTable(cmdText, cmdParam, out reternCode, out error);
            if (reternCode != "0000") return;
            if (dataTable.Rows.Count == 0) return;
            fileSavedName = common.AppSettingsGet("FileSavePath") +  common.GetStrVal(dataTable.Rows[0]["PICTURE_SAVED_NAME"]);
            if (System.IO.File.Exists(fileSavedName))
            {
                string thumbName = common.GetThumbnail(fileSavedName, 150, 100, out error);
                HttpContext.Current.Response.Clear();
                HttpContext.Current.Response.ContentType = "image/jpeg";
                HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + System.Web.HttpUtility.UrlEncode("applicantpicture", System.Text.Encoding.GetEncoding("utf-8")).Replace("+", " "));
                HttpContext.Current.Response.ContentType = "multipart/form-data";
                HttpContext.Current.Response.TransmitFile(thumbName);
                HttpContext.Current.Response.End();
            }
        }


    }
}
